/*******************************************************************************
* File Name: Fc.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Fc_H) /* Pins Fc_H */
#define CY_PINS_Fc_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Fc_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Fc__PORT == 15 && ((Fc__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Fc_Write(uint8 value);
void    Fc_SetDriveMode(uint8 mode);
uint8   Fc_ReadDataReg(void);
uint8   Fc_Read(void);
void    Fc_SetInterruptMode(uint16 position, uint16 mode);
uint8   Fc_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Fc_SetDriveMode() function.
     *  @{
     */
        #define Fc_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Fc_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Fc_DM_RES_UP          PIN_DM_RES_UP
        #define Fc_DM_RES_DWN         PIN_DM_RES_DWN
        #define Fc_DM_OD_LO           PIN_DM_OD_LO
        #define Fc_DM_OD_HI           PIN_DM_OD_HI
        #define Fc_DM_STRONG          PIN_DM_STRONG
        #define Fc_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Fc_MASK               Fc__MASK
#define Fc_SHIFT              Fc__SHIFT
#define Fc_WIDTH              1u

/* Interrupt constants */
#if defined(Fc__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Fc_SetInterruptMode() function.
     *  @{
     */
        #define Fc_INTR_NONE      (uint16)(0x0000u)
        #define Fc_INTR_RISING    (uint16)(0x0001u)
        #define Fc_INTR_FALLING   (uint16)(0x0002u)
        #define Fc_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Fc_INTR_MASK      (0x01u) 
#endif /* (Fc__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Fc_PS                     (* (reg8 *) Fc__PS)
/* Data Register */
#define Fc_DR                     (* (reg8 *) Fc__DR)
/* Port Number */
#define Fc_PRT_NUM                (* (reg8 *) Fc__PRT) 
/* Connect to Analog Globals */                                                  
#define Fc_AG                     (* (reg8 *) Fc__AG)                       
/* Analog MUX bux enable */
#define Fc_AMUX                   (* (reg8 *) Fc__AMUX) 
/* Bidirectional Enable */                                                        
#define Fc_BIE                    (* (reg8 *) Fc__BIE)
/* Bit-mask for Aliased Register Access */
#define Fc_BIT_MASK               (* (reg8 *) Fc__BIT_MASK)
/* Bypass Enable */
#define Fc_BYP                    (* (reg8 *) Fc__BYP)
/* Port wide control signals */                                                   
#define Fc_CTL                    (* (reg8 *) Fc__CTL)
/* Drive Modes */
#define Fc_DM0                    (* (reg8 *) Fc__DM0) 
#define Fc_DM1                    (* (reg8 *) Fc__DM1)
#define Fc_DM2                    (* (reg8 *) Fc__DM2) 
/* Input Buffer Disable Override */
#define Fc_INP_DIS                (* (reg8 *) Fc__INP_DIS)
/* LCD Common or Segment Drive */
#define Fc_LCD_COM_SEG            (* (reg8 *) Fc__LCD_COM_SEG)
/* Enable Segment LCD */
#define Fc_LCD_EN                 (* (reg8 *) Fc__LCD_EN)
/* Slew Rate Control */
#define Fc_SLW                    (* (reg8 *) Fc__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Fc_PRTDSI__CAPS_SEL       (* (reg8 *) Fc__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Fc_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Fc__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Fc_PRTDSI__OE_SEL0        (* (reg8 *) Fc__PRTDSI__OE_SEL0) 
#define Fc_PRTDSI__OE_SEL1        (* (reg8 *) Fc__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Fc_PRTDSI__OUT_SEL0       (* (reg8 *) Fc__PRTDSI__OUT_SEL0) 
#define Fc_PRTDSI__OUT_SEL1       (* (reg8 *) Fc__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Fc_PRTDSI__SYNC_OUT       (* (reg8 *) Fc__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Fc__SIO_CFG)
    #define Fc_SIO_HYST_EN        (* (reg8 *) Fc__SIO_HYST_EN)
    #define Fc_SIO_REG_HIFREQ     (* (reg8 *) Fc__SIO_REG_HIFREQ)
    #define Fc_SIO_CFG            (* (reg8 *) Fc__SIO_CFG)
    #define Fc_SIO_DIFF           (* (reg8 *) Fc__SIO_DIFF)
#endif /* (Fc__SIO_CFG) */

/* Interrupt Registers */
#if defined(Fc__INTSTAT)
    #define Fc_INTSTAT            (* (reg8 *) Fc__INTSTAT)
    #define Fc_SNAP               (* (reg8 *) Fc__SNAP)
    
	#define Fc_0_INTTYPE_REG 		(* (reg8 *) Fc__0__INTTYPE)
#endif /* (Fc__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Fc_H */


/* [] END OF FILE */
