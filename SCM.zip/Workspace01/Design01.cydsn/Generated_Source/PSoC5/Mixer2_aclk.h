/*******************************************************************************
* File Name: Mixer2_aclk.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_Mixer2_aclk_H)
#define CY_CLOCK_Mixer2_aclk_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void Mixer2_aclk_Start(void) ;
void Mixer2_aclk_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void Mixer2_aclk_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void Mixer2_aclk_StandbyPower(uint8 state) ;
void Mixer2_aclk_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 Mixer2_aclk_GetDividerRegister(void) ;
void Mixer2_aclk_SetModeRegister(uint8 modeBitMask) ;
void Mixer2_aclk_ClearModeRegister(uint8 modeBitMask) ;
uint8 Mixer2_aclk_GetModeRegister(void) ;
void Mixer2_aclk_SetSourceRegister(uint8 clkSource) ;
uint8 Mixer2_aclk_GetSourceRegister(void) ;
#if defined(Mixer2_aclk__CFG3)
void Mixer2_aclk_SetPhaseRegister(uint8 clkPhase) ;
uint8 Mixer2_aclk_GetPhaseRegister(void) ;
#endif /* defined(Mixer2_aclk__CFG3) */

#define Mixer2_aclk_Enable()                       Mixer2_aclk_Start()
#define Mixer2_aclk_Disable()                      Mixer2_aclk_Stop()
#define Mixer2_aclk_SetDivider(clkDivider)         Mixer2_aclk_SetDividerRegister(clkDivider, 1u)
#define Mixer2_aclk_SetDividerValue(clkDivider)    Mixer2_aclk_SetDividerRegister((clkDivider) - 1u, 1u)
#define Mixer2_aclk_SetMode(clkMode)               Mixer2_aclk_SetModeRegister(clkMode)
#define Mixer2_aclk_SetSource(clkSource)           Mixer2_aclk_SetSourceRegister(clkSource)
#if defined(Mixer2_aclk__CFG3)
#define Mixer2_aclk_SetPhase(clkPhase)             Mixer2_aclk_SetPhaseRegister(clkPhase)
#define Mixer2_aclk_SetPhaseValue(clkPhase)        Mixer2_aclk_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(Mixer2_aclk__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define Mixer2_aclk_CLKEN              (* (reg8 *) Mixer2_aclk__PM_ACT_CFG)
#define Mixer2_aclk_CLKEN_PTR          ((reg8 *) Mixer2_aclk__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define Mixer2_aclk_CLKSTBY            (* (reg8 *) Mixer2_aclk__PM_STBY_CFG)
#define Mixer2_aclk_CLKSTBY_PTR        ((reg8 *) Mixer2_aclk__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define Mixer2_aclk_DIV_LSB            (* (reg8 *) Mixer2_aclk__CFG0)
#define Mixer2_aclk_DIV_LSB_PTR        ((reg8 *) Mixer2_aclk__CFG0)
#define Mixer2_aclk_DIV_PTR            ((reg16 *) Mixer2_aclk__CFG0)

/* Clock MSB divider configuration register. */
#define Mixer2_aclk_DIV_MSB            (* (reg8 *) Mixer2_aclk__CFG1)
#define Mixer2_aclk_DIV_MSB_PTR        ((reg8 *) Mixer2_aclk__CFG1)

/* Mode and source configuration register */
#define Mixer2_aclk_MOD_SRC            (* (reg8 *) Mixer2_aclk__CFG2)
#define Mixer2_aclk_MOD_SRC_PTR        ((reg8 *) Mixer2_aclk__CFG2)

#if defined(Mixer2_aclk__CFG3)
/* Analog clock phase configuration register */
#define Mixer2_aclk_PHASE              (* (reg8 *) Mixer2_aclk__CFG3)
#define Mixer2_aclk_PHASE_PTR          ((reg8 *) Mixer2_aclk__CFG3)
#endif /* defined(Mixer2_aclk__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define Mixer2_aclk_CLKEN_MASK         Mixer2_aclk__PM_ACT_MSK
#define Mixer2_aclk_CLKSTBY_MASK       Mixer2_aclk__PM_STBY_MSK

/* CFG2 field masks */
#define Mixer2_aclk_SRC_SEL_MSK        Mixer2_aclk__CFG2_SRC_SEL_MASK
#define Mixer2_aclk_MODE_MASK          (~(Mixer2_aclk_SRC_SEL_MSK))

#if defined(Mixer2_aclk__CFG3)
/* CFG3 phase mask */
#define Mixer2_aclk_PHASE_MASK         Mixer2_aclk__CFG3_PHASE_DLY_MASK
#endif /* defined(Mixer2_aclk__CFG3) */

#endif /* CY_CLOCK_Mixer2_aclk_H */


/* [] END OF FILE */
