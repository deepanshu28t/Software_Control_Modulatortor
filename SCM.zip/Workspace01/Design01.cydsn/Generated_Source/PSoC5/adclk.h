/*******************************************************************************
* File Name: adclk.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_adclk_H)
#define CY_CLOCK_adclk_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void adclk_Start(void) ;
void adclk_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void adclk_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void adclk_StandbyPower(uint8 state) ;
void adclk_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 adclk_GetDividerRegister(void) ;
void adclk_SetModeRegister(uint8 modeBitMask) ;
void adclk_ClearModeRegister(uint8 modeBitMask) ;
uint8 adclk_GetModeRegister(void) ;
void adclk_SetSourceRegister(uint8 clkSource) ;
uint8 adclk_GetSourceRegister(void) ;
#if defined(adclk__CFG3)
void adclk_SetPhaseRegister(uint8 clkPhase) ;
uint8 adclk_GetPhaseRegister(void) ;
#endif /* defined(adclk__CFG3) */

#define adclk_Enable()                       adclk_Start()
#define adclk_Disable()                      adclk_Stop()
#define adclk_SetDivider(clkDivider)         adclk_SetDividerRegister(clkDivider, 1u)
#define adclk_SetDividerValue(clkDivider)    adclk_SetDividerRegister((clkDivider) - 1u, 1u)
#define adclk_SetMode(clkMode)               adclk_SetModeRegister(clkMode)
#define adclk_SetSource(clkSource)           adclk_SetSourceRegister(clkSource)
#if defined(adclk__CFG3)
#define adclk_SetPhase(clkPhase)             adclk_SetPhaseRegister(clkPhase)
#define adclk_SetPhaseValue(clkPhase)        adclk_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(adclk__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define adclk_CLKEN              (* (reg8 *) adclk__PM_ACT_CFG)
#define adclk_CLKEN_PTR          ((reg8 *) adclk__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define adclk_CLKSTBY            (* (reg8 *) adclk__PM_STBY_CFG)
#define adclk_CLKSTBY_PTR        ((reg8 *) adclk__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define adclk_DIV_LSB            (* (reg8 *) adclk__CFG0)
#define adclk_DIV_LSB_PTR        ((reg8 *) adclk__CFG0)
#define adclk_DIV_PTR            ((reg16 *) adclk__CFG0)

/* Clock MSB divider configuration register. */
#define adclk_DIV_MSB            (* (reg8 *) adclk__CFG1)
#define adclk_DIV_MSB_PTR        ((reg8 *) adclk__CFG1)

/* Mode and source configuration register */
#define adclk_MOD_SRC            (* (reg8 *) adclk__CFG2)
#define adclk_MOD_SRC_PTR        ((reg8 *) adclk__CFG2)

#if defined(adclk__CFG3)
/* Analog clock phase configuration register */
#define adclk_PHASE              (* (reg8 *) adclk__CFG3)
#define adclk_PHASE_PTR          ((reg8 *) adclk__CFG3)
#endif /* defined(adclk__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define adclk_CLKEN_MASK         adclk__PM_ACT_MSK
#define adclk_CLKSTBY_MASK       adclk__PM_STBY_MSK

/* CFG2 field masks */
#define adclk_SRC_SEL_MSK        adclk__CFG2_SRC_SEL_MASK
#define adclk_MODE_MASK          (~(adclk_SRC_SEL_MSK))

#if defined(adclk__CFG3)
/* CFG3 phase mask */
#define adclk_PHASE_MASK         adclk__CFG3_PHASE_DLY_MASK
#endif /* defined(adclk__CFG3) */

#endif /* CY_CLOCK_adclk_H */


/* [] END OF FILE */
