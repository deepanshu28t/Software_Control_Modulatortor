/*
 * ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
 */
#include "project.h"
#include "stdio.h"
#define LED_ON      1u
#define LED_OFF     0u


int a=3;
int end=1;
            
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
 LCD_Start();
 LCD_ClearDisplay();
    switch (a) {
    
    //..............CASE-1 FOR DSB-SC MODULATION (DSB-SC)....................
    case 1:
    LED_Write(LED_ON);
    LCD_ClearDisplay();
     AMux_Start();
    AMux_Select(0);
    Mixer1_Start();                    
    Mixer1_SetPower(Mixer1_MEDPOWER);
    
    LCD_Position(0,0);
    LCD_PrintString("DSB_SC");
   
    
    while(end!=5){
     };
    AMux_Stop();
    Mixer1_Stop();
    LED_Write(LED_OFF);
    break;
    
    
    //...............CASE-2 FOR AMPLITUDE MODULATION (AM).................
    case 2: 
    LED_Write(LED_ON);
    
    LCD_ClearDisplay();
    AMux_Start();
    AMux_Select(1);
    Mixer1_Start();
    Mixer1_SetPower(Mixer1_MEDPOWER);
    void WaveDAC8_Start(void);
    void WaveDAC8_Stop(void);////////
    LO_Start();
    Opamp_Start();
    
    LCD_Position(0,0);
    LCD_PrintString("AM");
    CyDelay(1000);
    while(end!=5){
      };
    AMux_Stop();
    Opamp_Stop();
    //void WaveDAC8_Stop(void);
    Mixer1_Stop();
    LO_Stop();
    
    LED_Write(LED_OFF);
    break;
    
    
    
    //................CASE-3 FOR BPSK MUDOLATION (BPSK).....................
    case 3: 
    LED_Write(LED_ON);
    LCD_ClearDisplay();
    AMux_Start();
    AMux_Select(2);
    while(end!=5){
    
    ADC_Start();
    ADC_StartConvert();
    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);

    LCD_Position(0,0);
    LCD_PrintString("BPSK");
    
    uint8 data= ADC_GetResult8();  //Getting the result from the ADC in data
    
    LCD_Position(1,0);
    LCD_PrintInt8(data);
    
    void Control_Reg_Write(uint8 data);  //Writing the data in the Control register
    
    uint8 Control_Reg_Read (void);
    //void Control_Reg_SaveConfig (void);
    LCD_Position(1,10);
    LCD_PrintInt8(Control_Reg_Read());
    
    
    void Mux_Start(void);
    CyDelay(20);
    
    
   //...........Try to change the sample rate of WAVEDAC8_1 from the top design.......
    WaveDAC8_1_Start();   //Starting the Digital to Analog converter
   
    void Clock1_Start(void);  // Clock1 is started which starts the counter.
    
    uint8 Status_Read(void); // Reading the status register to compare and stop the counter
    
    LCD_Position(1,5);
    LCD_PrintInt8(Status_Read());
    
    while( !Status_Read() ){
     }
    
    //   LCD_Position(1,8);
    //LCD_PrintString("A");;
    
    void Clock1_Stop(void);
    }
    AMux_Stop();
    void WaveDAC8_1_Stop(void);
    void Mux_Stop(void);
    ADC_Stop();
    
    LED_Write(LED_OFF);
    break;

    
    }
     
}

