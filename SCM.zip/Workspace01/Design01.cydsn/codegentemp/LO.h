/*******************************************************************************
* File Name: LO.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_LO_H)
#define CY_CLOCK_LO_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void LO_Start(void) ;
void LO_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void LO_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void LO_StandbyPower(uint8 state) ;
void LO_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 LO_GetDividerRegister(void) ;
void LO_SetModeRegister(uint8 modeBitMask) ;
void LO_ClearModeRegister(uint8 modeBitMask) ;
uint8 LO_GetModeRegister(void) ;
void LO_SetSourceRegister(uint8 clkSource) ;
uint8 LO_GetSourceRegister(void) ;
#if defined(LO__CFG3)
void LO_SetPhaseRegister(uint8 clkPhase) ;
uint8 LO_GetPhaseRegister(void) ;
#endif /* defined(LO__CFG3) */

#define LO_Enable()                       LO_Start()
#define LO_Disable()                      LO_Stop()
#define LO_SetDivider(clkDivider)         LO_SetDividerRegister(clkDivider, 1u)
#define LO_SetDividerValue(clkDivider)    LO_SetDividerRegister((clkDivider) - 1u, 1u)
#define LO_SetMode(clkMode)               LO_SetModeRegister(clkMode)
#define LO_SetSource(clkSource)           LO_SetSourceRegister(clkSource)
#if defined(LO__CFG3)
#define LO_SetPhase(clkPhase)             LO_SetPhaseRegister(clkPhase)
#define LO_SetPhaseValue(clkPhase)        LO_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(LO__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define LO_CLKEN              (* (reg8 *) LO__PM_ACT_CFG)
#define LO_CLKEN_PTR          ((reg8 *) LO__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define LO_CLKSTBY            (* (reg8 *) LO__PM_STBY_CFG)
#define LO_CLKSTBY_PTR        ((reg8 *) LO__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define LO_DIV_LSB            (* (reg8 *) LO__CFG0)
#define LO_DIV_LSB_PTR        ((reg8 *) LO__CFG0)
#define LO_DIV_PTR            ((reg16 *) LO__CFG0)

/* Clock MSB divider configuration register. */
#define LO_DIV_MSB            (* (reg8 *) LO__CFG1)
#define LO_DIV_MSB_PTR        ((reg8 *) LO__CFG1)

/* Mode and source configuration register */
#define LO_MOD_SRC            (* (reg8 *) LO__CFG2)
#define LO_MOD_SRC_PTR        ((reg8 *) LO__CFG2)

#if defined(LO__CFG3)
/* Analog clock phase configuration register */
#define LO_PHASE              (* (reg8 *) LO__CFG3)
#define LO_PHASE_PTR          ((reg8 *) LO__CFG3)
#endif /* defined(LO__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define LO_CLKEN_MASK         LO__PM_ACT_MSK
#define LO_CLKSTBY_MASK       LO__PM_STBY_MSK

/* CFG2 field masks */
#define LO_SRC_SEL_MSK        LO__CFG2_SRC_SEL_MASK
#define LO_MODE_MASK          (~(LO_SRC_SEL_MSK))

#if defined(LO__CFG3)
/* CFG3 phase mask */
#define LO_PHASE_MASK         LO__CFG3_PHASE_DLY_MASK
#endif /* defined(LO__CFG3) */

#endif /* CY_CLOCK_LO_H */


/* [] END OF FILE */
