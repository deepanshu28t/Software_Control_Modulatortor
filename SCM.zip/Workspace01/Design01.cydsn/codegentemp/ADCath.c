/*******************************************************************************
* File Name: ADCath.c
* Version 3.10
*
* Description:
*  This file provides the source code to the API for the Successive
*  approximation ADC Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CyLib.h"
#include "ADCath.h"

#if(ADCath_DEFAULT_INTERNAL_CLK)
    #include "ADCath_theACLK.h"
#endif /* End ADCath_DEFAULT_INTERNAL_CLK */


/***************************************
* Forward function references
***************************************/
static void ADCath_CalcGain(uint8 resolution);


/***************************************
* Global data allocation
***************************************/
uint8 ADCath_initVar = 0u;
volatile int16 ADCath_offset;
volatile int16 ADCath_countsPerVolt;     /* Obsolete Gain compensation */
volatile int32 ADCath_countsPer10Volt;   /* Gain compensation */
volatile int16 ADCath_shift;


/*******************************************************************************
* Function Name: ADCath_Start
********************************************************************************
*
* Summary:
*  This is the preferred method to begin component operation.
*  ADCath_Start() sets the initVar variable, calls the
*  ADCath_Init() function, and then calls the
*  ADCath_Enable() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  The ADCath_initVar variable is used to indicate when/if initial
*  configuration of this component has happened. The variable is initialized to
*  zero and set to 1 the first time ADC_Start() is called. This allows for
*  component Re-Start without re-initialization in all subsequent calls to the
*  ADCath_Start() routine.
*  If re-initialization of the component is required the variable should be set
*  to zero before call of ADCath_Start() routine, or the user may call
*  ADCath_Init() and ADCath_Enable() as done in the
*  ADCath_Start() routine.
*
* Side Effect:
*  If the initVar variable is already set, this function only calls the
*  ADCath_Enable() function.
*
*******************************************************************************/
void ADCath_Start(void)
{

    /* If not Initialized then initialize all required hardware and software */
    if(ADCath_initVar == 0u)
    {
        ADCath_Init();
        ADCath_initVar = 1u;
    }
    ADCath_Enable();
}


/*******************************************************************************
* Function Name: ADCath_Init
********************************************************************************
*
* Summary:
*  Initialize component's parameters to the parameters set by user in the
*  customizer of the component placed onto schematic. Usually called in
*  ADCath_Start().
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  The ADCath_offset variable is initialized to 0.
*
*******************************************************************************/
void ADCath_Init(void)
{

    /* This is only valid if there is an internal clock */
    #if(ADCath_DEFAULT_INTERNAL_CLK)
        ADCath_theACLK_SetMode(CYCLK_DUTY);
    #endif /* End ADCath_DEFAULT_INTERNAL_CLK */

    #if(ADCath_IRQ_REMOVE == 0u)
        /* Start and set interrupt vector */
        CyIntSetPriority(ADCath_INTC_NUMBER, ADCath_INTC_PRIOR_NUMBER);
        (void)CyIntSetVector(ADCath_INTC_NUMBER, &ADCath_ISR);
    #endif   /* End ADCath_IRQ_REMOVE */

    /* Enable IRQ mode*/
    ADCath_SAR_CSR1_REG |= ADCath_SAR_IRQ_MASK_EN | ADCath_SAR_IRQ_MODE_EDGE;

    /*Set SAR ADC resolution ADC */
    ADCath_SetResolution(ADCath_DEFAULT_RESOLUTION);
    ADCath_offset = 0;
}


/*******************************************************************************
* Function Name: ADCath_Enable
********************************************************************************
*
* Summary:
*  Enables the reference, clock and power for SAR ADC.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void ADCath_Enable(void)
{
    uint8 tmpReg;
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    /* Enable the SAR ADC block in Active Power Mode */
    ADCath_PWRMGR_SAR_REG |= ADCath_ACT_PWR_SAR_EN;

     /* Enable the SAR ADC in Standby Power Mode*/
    ADCath_STBY_PWRMGR_SAR_REG |= ADCath_STBY_PWR_SAR_EN;

    /* This is only valid if there is an internal clock */
    #if(ADCath_DEFAULT_INTERNAL_CLK)
        ADCath_PWRMGR_CLK_REG |= ADCath_ACT_PWR_CLK_EN;
        ADCath_STBY_PWRMGR_CLK_REG |= ADCath_STBY_PWR_CLK_EN;
    #endif /* End ADCath_DEFAULT_INTERNAL_CLK */

    /* Enable VCM buffer and Enable Int Ref Amp */
    tmpReg = ADCath_SAR_CSR3_REG;
    tmpReg |= ADCath_SAR_EN_BUF_VCM_EN;
    /* PD_BUF_VREF is OFF in External reference or Vdda reference mode */
    #if((ADCath_DEFAULT_REFERENCE == ADCath__EXT_REF) || \
        (ADCath_DEFAULT_RANGE == ADCath__VNEG_VDDA_DIFF))
        tmpReg &= (uint8)~ADCath_SAR_EN_BUF_VREF_EN;
    #else /* In INTREF or INTREF Bypassed this buffer is ON */
        tmpReg |= ADCath_SAR_EN_BUF_VREF_EN;
    #endif /* ADCath_DEFAULT_REFERENCE == ADCath__EXT_REF */
    ADCath_SAR_CSR3_REG = tmpReg;

    /* Set reference for ADC */
    #if(ADCath_DEFAULT_RANGE == ADCath__VNEG_VDDA_DIFF)
        #if(ADCath_DEFAULT_REFERENCE == ADCath__EXT_REF)
            ADCath_SAR_CSR6_REG = ADCath_INT_BYPASS_EXT_VREF; /* S2 */
        #else /* Internal Vdda reference or obsolete bypass mode */
            ADCath_SAR_CSR6_REG = ADCath_VDDA_VREF;           /* S7 */
        #endif /* ADCath_DEFAULT_REFERENCE == ADCath__EXT_REF */
    #else  /* Reference goes through internal buffer */
        #if(ADCath_DEFAULT_REFERENCE == ADCath__INT_REF_NOT_BYPASSED)
            ADCath_SAR_CSR6_REG = ADCath_INT_VREF;            /* S3 + S4 */
        #else /* INTREF Bypassed of External */
            ADCath_SAR_CSR6_REG = ADCath_INT_BYPASS_EXT_VREF; /* S2 */
        #endif /* ADCath_DEFAULT_REFERENCE == ADCath__INT_REF_NOT_BYPASSED */
    #endif /* VNEG_VDDA_DIFF */

    /* Low non-overlap delay for sampling clock signals (for 1MSPS) */
    #if(ADCath_HIGH_POWER_PULSE == 0u) /* MinPulseWidth <= 50 ns */
        ADCath_SAR_CSR5_REG &= (uint8)~ADCath_SAR_DLY_INC;
    #else /* Set High non-overlap delay for sampling clock signals (for <500KSPS)*/
        ADCath_SAR_CSR5_REG |= ADCath_SAR_DLY_INC;
    #endif /* ADCath_HIGH_POWER_PULSE == 0u */

    /* Increase comparator latch enable delay by 20%, 
    *  Increase comparator bias current by 30% without impacting delaysDelay 
    *  Default for 1MSPS) 
    */
    #if(ADCath_HIGH_POWER_PULSE == 0u)    /* MinPulseWidth <= 50 ns */
        ADCath_SAR_CSR5_REG |= ADCath_SAR_SEL_CSEL_DFT_CHAR;
    #else /* for <500ksps */
        ADCath_SAR_CSR5_REG &= (uint8)~ADCath_SAR_SEL_CSEL_DFT_CHAR;
    #endif /* ADCath_HIGH_POWER_PULSE == 0u */

    /* Set default power and other configurations for control register 0 in multiple lines */
    ADCath_SAR_CSR0_REG = (uint8)((uint8)ADCath_DEFAULT_POWER << ADCath_SAR_POWER_SHIFT)
    /* SAR_HIZ_CLEAR:   Should not be used for LP */
    #if ((CY_PSOC5LP) || (ADCath_DEFAULT_REFERENCE != ADCath__EXT_REF))
        | ADCath_SAR_HIZ_CLEAR
    #endif /* SAR_HIZ_CLEAR */
    /*Set Convertion mode */
    #if(ADCath_DEFAULT_CONV_MODE != ADCath__FREE_RUNNING)      /* If triggered mode */
        | ADCath_SAR_MX_SOF_UDB           /* source: UDB */
        | ADCath_SAR_SOF_MODE_EDGE        /* Set edge-sensitive sof source */
    #endif /* ADCath_DEFAULT_CONV_MODE */
    ; /* end of multiple line initialization */

    ADCath_SAR_TR0_REG = ADCath_SAR_CAP_TRIM_2;

    /* Enable clock for SAR ADC*/
    ADCath_SAR_CLK_REG |= ADCath_SAR_MX_CLK_EN;

    CyDelayUs(10u); /* The block is ready to use 10 us after the enable signal is set high. */

    #if(ADCath_IRQ_REMOVE == 0u)
        /* Clear a pending interrupt */
        CyIntClearPending(ADCath_INTC_NUMBER);
    #endif   /* End ADCath_IRQ_REMOVE */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: ADCath_Stop
********************************************************************************
*
* Summary:
*  Stops ADC conversions and puts the ADC into its lowest power mode.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void ADCath_Stop(void)
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    /* Stop all conversions */
    ADCath_SAR_CSR0_REG &= (uint8)~ADCath_SAR_SOF_START_CONV;
    /* Disable the SAR ADC block in Active Power Mode */
    ADCath_PWRMGR_SAR_REG &= (uint8)~ADCath_ACT_PWR_SAR_EN;
    /* Disable the SAR ADC in Standby Power Mode */
    ADCath_STBY_PWRMGR_SAR_REG &= (uint8)~ADCath_STBY_PWR_SAR_EN;

    /* This is only valid if there is an internal clock */
    #if(ADCath_DEFAULT_INTERNAL_CLK)
        ADCath_PWRMGR_CLK_REG &= (uint8)~ADCath_ACT_PWR_CLK_EN;
        ADCath_STBY_PWRMGR_CLK_REG &= (uint8)~ADCath_STBY_PWR_CLK_EN;
    #endif /* End ADCath_DEFAULT_INTERNAL_CLK */

    CyExitCriticalSection(enableInterrupts);

}


/*******************************************************************************
* Function Name: ADCath_SetPower
********************************************************************************
*
* Summary:
*  Sets the operational power of the ADC. You should use the higher power
*  settings with faster clock speeds.
*
* Parameters:
*  power:  Power setting for ADC
*  0 ->    Normal
*  1 ->    Medium power
*  2 ->    1.25 power
*  3 ->    Minimum power.
*
* Return:
*  None.
*
*******************************************************************************/
void ADCath_SetPower(uint8 power)
{
    uint8 tmpReg;

    /* mask off invalid power settings */
    power &= ADCath_SAR_API_POWER_MASK;

    /* Set Power parameter  */
    tmpReg = ADCath_SAR_CSR0_REG & (uint8)~ADCath_SAR_POWER_MASK;
    tmpReg |= (uint8)(power << ADCath_SAR_POWER_SHIFT);
    ADCath_SAR_CSR0_REG = tmpReg;
}


/*******************************************************************************
* Function Name: ADCath_SetResolution
********************************************************************************
*
* Summary:
*  Sets the Relution of the SAR.
*
* Parameters:
*  resolution:
*  12 ->    RES12
*  10 ->    RES10
*  8  ->    RES8
*
* Return:
*  None.
*
* Side Effects:
*  The ADC resolution cannot be changed during a conversion cycle. The
*  recommended best practice is to stop conversions with
*  ADC_StopConvert(), change the resolution, then restart the
*  conversions with ADC_StartConvert().
*  If you decide not to stop conversions before calling this API, you
*  should use ADC_IsEndConversion() to wait until conversion is complete
*  before changing the resolution.
*  If you call ADC_SetResolution() during a conversion, the resolution will
*  not be changed until the current conversion is complete. Data will not be
*  available in the new resolution for another 6 + "New Resolution(in bits)"
*  clock cycles.
*  You may need add a delay of this number of clock cycles after
*  ADC_SetResolution() is called before data is valid again.
*  Affects ADC_CountsTo_Volts(), ADC_CountsTo_mVolts(), and
*  ADC_CountsTo_uVolts() by calculating the correct conversion between ADC
*  counts and the applied input voltage. Calculation depends on resolution,
*  input range, and voltage reference.
*
*******************************************************************************/
void ADCath_SetResolution(uint8 resolution)
{
    uint8 tmpReg;

    /* Set SAR ADC resolution and sample width: 18 conversion cycles at 12bits + 1 gap */
    switch (resolution)
    {
        case (uint8)ADCath__BITS_12:
            tmpReg = ADCath_SAR_RESOLUTION_12BIT | ADCath_SAR_SAMPLE_WIDTH;
            break;
        case (uint8)ADCath__BITS_10:
            tmpReg = ADCath_SAR_RESOLUTION_10BIT | ADCath_SAR_SAMPLE_WIDTH;
            break;
        case (uint8)ADCath__BITS_8:
            tmpReg = ADCath_SAR_RESOLUTION_8BIT | ADCath_SAR_SAMPLE_WIDTH;
            break;
        default:
            tmpReg = ADCath_SAR_RESOLUTION_12BIT | ADCath_SAR_SAMPLE_WIDTH;
            /* Halt CPU in debug mode if resolution is out of valid range */
            CYASSERT(0u != 0u);
            break;
    }
    ADCath_SAR_CSR2_REG = tmpReg;

     /* Calculate gain for convert counts to volts */
    ADCath_CalcGain(resolution);
}


#if(ADCath_DEFAULT_CONV_MODE != ADCath__HARDWARE_TRIGGER)


    /*******************************************************************************
    * Function Name: ADCath_StartConvert
    ********************************************************************************
    *
    * Summary:
    *  Forces the ADC to initiate a conversion. In free-running mode, the ADC runs
    *  continuously. In software trigger mode, the function also acts as a software
    *  version of the SOC and every conversion must be triggered by
    *  ADCath_StartConvert(). This function is not available when the
    *  Hardware Trigger sample mode is selected.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Forces the ADC to initiate a conversion. In Free Running mode, the ADC will
    *  run continuously. In a software trigger mode the function also acts as a
    *  software version of the SOC. Here every conversion has to be triggered by
    *  the routine. This writes into the SOC bit in SAR_CTRL reg.
    *
    * Side Effects:
    *  In a software trigger mode the function switches source for SOF from the
    *  external pin to the internal SOF generation. Application should not call
    *  StartConvert if external source used for SOF.
    *
    *******************************************************************************/
    void ADCath_StartConvert(void)
    {
        #if(ADCath_DEFAULT_CONV_MODE != ADCath__FREE_RUNNING)  /* If software triggered mode */
            ADCath_SAR_CSR0_REG &= (uint8)~ADCath_SAR_MX_SOF_UDB;   /* source: SOF bit */
        #endif /* End ADCath_DEFAULT_CONV_MODE */

        /* Start the conversion */
        ADCath_SAR_CSR0_REG |= ADCath_SAR_SOF_START_CONV;
    }


    /*******************************************************************************
    * Function Name: ADCath_StopConvert
    ********************************************************************************
    *
    * Summary:
    *  Forces the ADC to stop conversions. If a conversion is currently executing,
    *  that conversion will complete, but no further conversions will occur. This
    *  function is not available when the Hardware Trigger sample mode is selected.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Stops ADC conversion in Free Running mode.
    *
    * Side Effects:
    *  In Software Trigger sample mode, this function sets a software version of the
    *  SOC to low level and switches the SOC source to hardware SOC input.
    *
    *******************************************************************************/
    void ADCath_StopConvert(void)
    {
        /* Stop all conversions */
        ADCath_SAR_CSR0_REG &= (uint8)~ADCath_SAR_SOF_START_CONV;

        #if(ADCath_DEFAULT_CONV_MODE != ADCath__FREE_RUNNING)  /* If software triggered mode */
            /* Return source to UDB for hardware SOF signal */
            ADCath_SAR_CSR0_REG |= ADCath_SAR_MX_SOF_UDB;    /* source: UDB */
        #endif /* End ADCath_DEFAULT_CONV_MODE */

    }

#endif /* End ADCath_DEFAULT_CONV_MODE != ADCath__HARDWARE_TRIGGER */


/*******************************************************************************
* Function Name: ADCath_IsEndConversion
********************************************************************************
*
* Summary:
*  Immediately returns the status of the conversion or does not return
*  (blocking) until the conversion completes, depending on the retMode
*  parameter.
*
* Parameters:
*  retMode:  Check conversion return mode.
*   ADCath_RETURN_STATUS: Immediately returns the status. If the
*     value returned is zero, the conversion is not complete, and this function
*     should be retried until a nonzero result is returned.
*   ADCath_WAIT_FOR_RESULT: Does not return a result until the ADC
*     conversion is complete.
*
* Return:
*  (uint8)  0 =>  The ADC is still calculating the last result.
*           1 =>  The last conversion is complete.
*
* Side Effects:
*  This function reads the end of conversion status, which is cleared on read.
*
*******************************************************************************/
uint8 ADCath_IsEndConversion(uint8 retMode)
{
    uint8 status;

    do
    {
        status = ADCath_SAR_CSR1_REG & ADCath_SAR_EOF_1;
    } while ((status != ADCath_SAR_EOF_1) && (retMode == ADCath_WAIT_FOR_RESULT));
    /* If convertion complete, wait until EOF bit released */
    if(status == ADCath_SAR_EOF_1)
    {
        /* wait one ADC clock to let the EOC status bit release */
        CyDelayUs(1u);
        /* Do the unconditional read operation of the CSR1 register to make sure the EOC bit has been cleared */
        CY_GET_REG8(ADCath_SAR_CSR1_PTR);
    }

    return(status);
}


/*******************************************************************************
* Function Name: ADCath_GetResult8
********************************************************************************
*
* Summary:
*  Returns the result of an 8-bit conversion. If the resolution is set greater
*  than 8 bits, the function returns the LSB of the result.
*  ADCath_IsEndConversion() should be called to verify that the data
*   sample is ready.
*
* Parameters:
*  None.
*
* Return:
*  The LSB of the last ADC conversion.
*
* Global Variables:
*  ADCath_shift - used to convert the ADC counts to the 2s
*  compliment form.
*
* Side Effects:
*  Converts the ADC counts to the 2s complement form.
*
*******************************************************************************/
int8 ADCath_GetResult8( void )
{
    return( (int8)ADCath_SAR_WRK0_REG - (int8)ADCath_shift);
}


/*******************************************************************************
* Function Name: ADCath_GetResult16
********************************************************************************
*
* Summary:
*  Returns a 16-bit result for a conversion with a result that has a resolution
*  of 8 to 12 bits.
*  ADCath_IsEndConversion() should be called to verify that the data
*   sample is ready
*
* Parameters:
*  None.
*
* Return:
*  The 16-bit result of the last ADC conversion
*
* Global Variables:
*  ADCath_shift - used to convert the ADC counts to the 2s
*  compliment form.
*
* Side Effects:
*  Converts the ADC counts to the 2s complement form.
*
*******************************************************************************/
int16 ADCath_GetResult16( void )
{
    uint16 res;

    res = CY_GET_REG16(ADCath_SAR_WRK_PTR);

    return( (int16)res - ADCath_shift );
}


/*******************************************************************************
* Function Name: ADCath_SetOffset
********************************************************************************
*
* Summary:
*  Sets the ADC offset, which is used by ADCath_CountsTo_Volts(),
*  ADCath_CountsTo_mVolts(), and ADCath_CountsTo_uVolts()
*  to subtract the offset from the given reading before calculating the voltage
*  conversion.
*
* Parameters:
*  int16: This value is measured when the inputs are shorted or connected to
   the same input voltage.
*
* Return:
*  None.
*
* Global Variables:
*  The ADCath_offset variable modified. This variable is used for
*  offset calibration purpose.
*  Affects the ADCath_CountsTo_Volts,
*  ADCath_CountsTo_mVolts, ADCath_CountsTo_uVolts functions
*  by subtracting the given offset.
*
*******************************************************************************/
void ADCath_SetOffset(int16 offset)
{
    ADCath_offset = offset;
}


/*******************************************************************************
* Function Name: ADCath_CalcGain
********************************************************************************
*
* Summary:
*  This function calculates the ADC gain in counts per 10 volt.
*
* Parameters:
*  uint8: resolution
*
* Return:
*  None.
*
* Global Variables:
*  ADCath_shift variable initialized. This variable is used to
*  convert the ADC counts to the 2s compliment form.
*  ADCath_countsPer10Volt variable initialized. This variable is used
*  for gain calibration purpose.
*
*******************************************************************************/
static void ADCath_CalcGain( uint8 resolution )
{
    int32 counts;
    #if(!((ADCath_DEFAULT_RANGE == ADCath__VSS_TO_VREF) || \
         (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDDA) || \
         (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDAC)) )
        uint16 diff_zero;
    #endif /* End ADCath_DEFAULT_RANGE */

    switch (resolution)
    {
        case (uint8)ADCath__BITS_12:
            counts = (int32)ADCath_SAR_WRK_MAX_12BIT;
            #if(!((ADCath_DEFAULT_RANGE == ADCath__VSS_TO_VREF) || \
                 (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDDA) || \
                 (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDAC)) )
                diff_zero = ADCath_SAR_DIFF_SHIFT;
            #endif /* End ADCath_DEFAULT_RANGE */
            break;
        case (uint8)ADCath__BITS_10:
            counts = (int32)ADCath_SAR_WRK_MAX_10BIT;
            #if(!((ADCath_DEFAULT_RANGE == ADCath__VSS_TO_VREF) || \
                 (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDDA) || \
                 (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDAC)) )
                diff_zero = ADCath_SAR_DIFF_SHIFT >> 2u;
            #endif /* End ADCath_DEFAULT_RANGE */
            break;
        case (uint8)ADCath__BITS_8:
            counts = (int32)ADCath_SAR_WRK_MAX_8BIT;
            #if(!((ADCath_DEFAULT_RANGE == ADCath__VSS_TO_VREF) || \
                 (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDDA) || \
                 (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDAC)) )
                diff_zero = ADCath_SAR_DIFF_SHIFT >> 4u;
            #endif /* End ADCath_DEFAULT_RANGE */
            break;
        default: /* Halt CPU in debug mode if resolution is out of valid range */
            counts = 0;
            #if(!((ADCath_DEFAULT_RANGE == ADCath__VSS_TO_VREF) || \
                 (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDDA) || \
                 (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDAC)) )
                diff_zero = 0u;
            #endif /* End ADCath_DEFAULT_RANGE */
            CYASSERT(0u != 0u);
            break;
    }
    ADCath_countsPerVolt = 0; /* Clear obsolete variable */
    /* Calculate gain in counts per 10 volts with rounding */
    ADCath_countsPer10Volt = (((counts * ADCath_10MV_COUNTS) +
                        ADCath_DEFAULT_REF_VOLTAGE_MV) / (ADCath_DEFAULT_REF_VOLTAGE_MV * 2));

    #if( (ADCath_DEFAULT_RANGE == ADCath__VSS_TO_VREF) || \
         (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDDA) || \
         (ADCath_DEFAULT_RANGE == ADCath__VSSA_TO_VDAC) )
        ADCath_shift = 0;
    #else
        ADCath_shift = diff_zero;
    #endif /* End ADCath_DEFAULT_RANGE */
}


/*******************************************************************************
* Function Name: ADCath_SetGain
********************************************************************************
*
* Summary:
*  Sets the ADC gain in counts per volt for the voltage conversion functions
*  that follow. This value is set by default by the reference and input range
*  settings. It should only be used to further calibrate the ADC with a known
*  input or if the ADC is using an external reference.
*
* Parameters:
*  int16 adcGain counts per volt
*
* Return:
*  None.
*
* Global Variables:
*  ADCath_countsPer10Volt variable modified. This variable is used
*  for gain calibration purpose.
*
*******************************************************************************/
void ADCath_SetGain(int16 adcGain)
{
    ADCath_countsPer10Volt = (int32)adcGain * 10;
}


/*******************************************************************************
* Function Name: ADCath_SetScaledGain
********************************************************************************
*
* Summary:
*  Sets the ADC gain in counts per 10 volt for the voltage conversion functions
*  that follow. This value is set by default by the reference and input range
*  settings. It should only be used to further calibrate the ADC with a known
*  input or if the ADC is using an external reference.
*
* Parameters:
*  int32 adcGain  counts per 10 volt
*
* Return:
*  None.
*
* Global Variables:
*  ADCath_countsPer10Volt variable modified. This variable is used
*  for gain calibration purpose.
*
*******************************************************************************/
void ADCath_SetScaledGain(int32 adcGain)
{
    ADCath_countsPer10Volt = adcGain;
}


/*******************************************************************************
* Function Name: ADCath_CountsTo_mVolts
********************************************************************************
*
* Summary:
*  Converts the ADC output to millivolts as a 16-bit integer.
*
* Parameters:
*  int16 adcCounts:  Result from the ADC conversion
*
* Return:
*  int16 Result in mVolts
*
* Global Variables:
*  ADCath_offset variable used.
*  ADCath_countsPer10Volt variable used.
*
*******************************************************************************/
int16 ADCath_CountsTo_mVolts(int16 adcCounts)
{
    int16 mVolts;
    int32 countsPer10Volt;

    if(ADCath_countsPerVolt != 0)
    {   /* Support obsolete method */
        countsPer10Volt = (int32)ADCath_countsPerVolt * 10;
    }
    else
    {
        countsPer10Volt = ADCath_countsPer10Volt;
    }

    /* Subtract ADC offset */
    adcCounts -= ADCath_offset;
    /* Convert to millivolts with rounding */
    mVolts = (int16)( (( (int32)adcCounts * ADCath_10MV_COUNTS ) + ( (adcCounts > 0) ?
                       (countsPer10Volt / 2) : (-(countsPer10Volt / 2)) )) / countsPer10Volt);

    return( mVolts );
}


/*******************************************************************************
* Function Name: ADCath_CountsTo_uVolts
********************************************************************************
*
* Summary:
*  Converts the ADC output to microvolts as a 32-bit integer.
*
* Parameters:
*  int16 adcCounts: Result from the ADC conversion
*
* Return:
*  int32 Result in micro Volts
*
* Global Variables:
*  ADCath_offset variable used.
*  ADCath_countsPer10Volt used to convert ADC counts to uVolts.
*
*******************************************************************************/
int32 ADCath_CountsTo_uVolts(int16 adcCounts)
{

    int64 uVolts;
    int32 countsPer10Volt;

    if(ADCath_countsPerVolt != 0)
    {   /* Support obsolete method */
        countsPer10Volt = (int32)ADCath_countsPerVolt * 10;
    }
    else
    {
        countsPer10Volt = ADCath_countsPer10Volt;
    }

    /* Subtract ADC offset */
    adcCounts -= ADCath_offset;
    /* To convert adcCounts to microVolts it is required to be multiplied
    *  on 10 million and later divide on gain in counts per 10V.
    */
    uVolts = (( (int64)adcCounts * ADCath_10UV_COUNTS ) / countsPer10Volt);

    return((int32) uVolts );
}


/*******************************************************************************
* Function Name: ADCath_CountsTo_Volts
********************************************************************************
*
* Summary:
*  Converts the ADC output to volts as a floating-point number.
*
* Parameters:
*  int16 adcCounts: Result from the ADC conversion
*
* Return:
*  float Result in Volts
*
* Global Variables:
*  ADCath_offset variable used.
*  ADCath_countsPer10Volt used to convert ADC counts to Volts.
*
*******************************************************************************/
float32 ADCath_CountsTo_Volts(int16 adcCounts)
{
    float32 volts;
    int32 countsPer10Volt;

    if(ADCath_countsPerVolt != 0)
    {   /* Support obsolete method */
        countsPer10Volt = (int32)ADCath_countsPerVolt * 10;
    }
    else
    {
        countsPer10Volt = ADCath_countsPer10Volt;
    }

    /* Subtract ADC offset */
    adcCounts -= ADCath_offset;

    volts = ((float32)adcCounts * ADCath_10V_COUNTS) / (float32)countsPer10Volt;

    return( volts );
}


/* [] END OF FILE */
