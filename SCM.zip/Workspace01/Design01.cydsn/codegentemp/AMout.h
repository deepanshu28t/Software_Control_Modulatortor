/*******************************************************************************
* File Name: AMout.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_AMout_H) /* Pins AMout_H */
#define CY_PINS_AMout_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "AMout_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 AMout__PORT == 15 && ((AMout__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    AMout_Write(uint8 value);
void    AMout_SetDriveMode(uint8 mode);
uint8   AMout_ReadDataReg(void);
uint8   AMout_Read(void);
void    AMout_SetInterruptMode(uint16 position, uint16 mode);
uint8   AMout_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the AMout_SetDriveMode() function.
     *  @{
     */
        #define AMout_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define AMout_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define AMout_DM_RES_UP          PIN_DM_RES_UP
        #define AMout_DM_RES_DWN         PIN_DM_RES_DWN
        #define AMout_DM_OD_LO           PIN_DM_OD_LO
        #define AMout_DM_OD_HI           PIN_DM_OD_HI
        #define AMout_DM_STRONG          PIN_DM_STRONG
        #define AMout_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define AMout_MASK               AMout__MASK
#define AMout_SHIFT              AMout__SHIFT
#define AMout_WIDTH              1u

/* Interrupt constants */
#if defined(AMout__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in AMout_SetInterruptMode() function.
     *  @{
     */
        #define AMout_INTR_NONE      (uint16)(0x0000u)
        #define AMout_INTR_RISING    (uint16)(0x0001u)
        #define AMout_INTR_FALLING   (uint16)(0x0002u)
        #define AMout_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define AMout_INTR_MASK      (0x01u) 
#endif /* (AMout__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define AMout_PS                     (* (reg8 *) AMout__PS)
/* Data Register */
#define AMout_DR                     (* (reg8 *) AMout__DR)
/* Port Number */
#define AMout_PRT_NUM                (* (reg8 *) AMout__PRT) 
/* Connect to Analog Globals */                                                  
#define AMout_AG                     (* (reg8 *) AMout__AG)                       
/* Analog MUX bux enable */
#define AMout_AMUX                   (* (reg8 *) AMout__AMUX) 
/* Bidirectional Enable */                                                        
#define AMout_BIE                    (* (reg8 *) AMout__BIE)
/* Bit-mask for Aliased Register Access */
#define AMout_BIT_MASK               (* (reg8 *) AMout__BIT_MASK)
/* Bypass Enable */
#define AMout_BYP                    (* (reg8 *) AMout__BYP)
/* Port wide control signals */                                                   
#define AMout_CTL                    (* (reg8 *) AMout__CTL)
/* Drive Modes */
#define AMout_DM0                    (* (reg8 *) AMout__DM0) 
#define AMout_DM1                    (* (reg8 *) AMout__DM1)
#define AMout_DM2                    (* (reg8 *) AMout__DM2) 
/* Input Buffer Disable Override */
#define AMout_INP_DIS                (* (reg8 *) AMout__INP_DIS)
/* LCD Common or Segment Drive */
#define AMout_LCD_COM_SEG            (* (reg8 *) AMout__LCD_COM_SEG)
/* Enable Segment LCD */
#define AMout_LCD_EN                 (* (reg8 *) AMout__LCD_EN)
/* Slew Rate Control */
#define AMout_SLW                    (* (reg8 *) AMout__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define AMout_PRTDSI__CAPS_SEL       (* (reg8 *) AMout__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define AMout_PRTDSI__DBL_SYNC_IN    (* (reg8 *) AMout__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define AMout_PRTDSI__OE_SEL0        (* (reg8 *) AMout__PRTDSI__OE_SEL0) 
#define AMout_PRTDSI__OE_SEL1        (* (reg8 *) AMout__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define AMout_PRTDSI__OUT_SEL0       (* (reg8 *) AMout__PRTDSI__OUT_SEL0) 
#define AMout_PRTDSI__OUT_SEL1       (* (reg8 *) AMout__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define AMout_PRTDSI__SYNC_OUT       (* (reg8 *) AMout__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(AMout__SIO_CFG)
    #define AMout_SIO_HYST_EN        (* (reg8 *) AMout__SIO_HYST_EN)
    #define AMout_SIO_REG_HIFREQ     (* (reg8 *) AMout__SIO_REG_HIFREQ)
    #define AMout_SIO_CFG            (* (reg8 *) AMout__SIO_CFG)
    #define AMout_SIO_DIFF           (* (reg8 *) AMout__SIO_DIFF)
#endif /* (AMout__SIO_CFG) */

/* Interrupt Registers */
#if defined(AMout__INTSTAT)
    #define AMout_INTSTAT            (* (reg8 *) AMout__INTSTAT)
    #define AMout_SNAP               (* (reg8 *) AMout__SNAP)
    
	#define AMout_0_INTTYPE_REG 		(* (reg8 *) AMout__0__INTTYPE)
#endif /* (AMout__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_AMout_H */


/* [] END OF FILE */
