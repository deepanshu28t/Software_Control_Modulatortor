/*******************************************************************************
* File Name: DSBout.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DSBout_H) /* Pins DSBout_H */
#define CY_PINS_DSBout_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DSBout_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 DSBout__PORT == 15 && ((DSBout__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    DSBout_Write(uint8 value);
void    DSBout_SetDriveMode(uint8 mode);
uint8   DSBout_ReadDataReg(void);
uint8   DSBout_Read(void);
void    DSBout_SetInterruptMode(uint16 position, uint16 mode);
uint8   DSBout_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the DSBout_SetDriveMode() function.
     *  @{
     */
        #define DSBout_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define DSBout_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define DSBout_DM_RES_UP          PIN_DM_RES_UP
        #define DSBout_DM_RES_DWN         PIN_DM_RES_DWN
        #define DSBout_DM_OD_LO           PIN_DM_OD_LO
        #define DSBout_DM_OD_HI           PIN_DM_OD_HI
        #define DSBout_DM_STRONG          PIN_DM_STRONG
        #define DSBout_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define DSBout_MASK               DSBout__MASK
#define DSBout_SHIFT              DSBout__SHIFT
#define DSBout_WIDTH              1u

/* Interrupt constants */
#if defined(DSBout__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in DSBout_SetInterruptMode() function.
     *  @{
     */
        #define DSBout_INTR_NONE      (uint16)(0x0000u)
        #define DSBout_INTR_RISING    (uint16)(0x0001u)
        #define DSBout_INTR_FALLING   (uint16)(0x0002u)
        #define DSBout_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define DSBout_INTR_MASK      (0x01u) 
#endif /* (DSBout__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DSBout_PS                     (* (reg8 *) DSBout__PS)
/* Data Register */
#define DSBout_DR                     (* (reg8 *) DSBout__DR)
/* Port Number */
#define DSBout_PRT_NUM                (* (reg8 *) DSBout__PRT) 
/* Connect to Analog Globals */                                                  
#define DSBout_AG                     (* (reg8 *) DSBout__AG)                       
/* Analog MUX bux enable */
#define DSBout_AMUX                   (* (reg8 *) DSBout__AMUX) 
/* Bidirectional Enable */                                                        
#define DSBout_BIE                    (* (reg8 *) DSBout__BIE)
/* Bit-mask for Aliased Register Access */
#define DSBout_BIT_MASK               (* (reg8 *) DSBout__BIT_MASK)
/* Bypass Enable */
#define DSBout_BYP                    (* (reg8 *) DSBout__BYP)
/* Port wide control signals */                                                   
#define DSBout_CTL                    (* (reg8 *) DSBout__CTL)
/* Drive Modes */
#define DSBout_DM0                    (* (reg8 *) DSBout__DM0) 
#define DSBout_DM1                    (* (reg8 *) DSBout__DM1)
#define DSBout_DM2                    (* (reg8 *) DSBout__DM2) 
/* Input Buffer Disable Override */
#define DSBout_INP_DIS                (* (reg8 *) DSBout__INP_DIS)
/* LCD Common or Segment Drive */
#define DSBout_LCD_COM_SEG            (* (reg8 *) DSBout__LCD_COM_SEG)
/* Enable Segment LCD */
#define DSBout_LCD_EN                 (* (reg8 *) DSBout__LCD_EN)
/* Slew Rate Control */
#define DSBout_SLW                    (* (reg8 *) DSBout__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DSBout_PRTDSI__CAPS_SEL       (* (reg8 *) DSBout__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DSBout_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DSBout__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DSBout_PRTDSI__OE_SEL0        (* (reg8 *) DSBout__PRTDSI__OE_SEL0) 
#define DSBout_PRTDSI__OE_SEL1        (* (reg8 *) DSBout__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DSBout_PRTDSI__OUT_SEL0       (* (reg8 *) DSBout__PRTDSI__OUT_SEL0) 
#define DSBout_PRTDSI__OUT_SEL1       (* (reg8 *) DSBout__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DSBout_PRTDSI__SYNC_OUT       (* (reg8 *) DSBout__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(DSBout__SIO_CFG)
    #define DSBout_SIO_HYST_EN        (* (reg8 *) DSBout__SIO_HYST_EN)
    #define DSBout_SIO_REG_HIFREQ     (* (reg8 *) DSBout__SIO_REG_HIFREQ)
    #define DSBout_SIO_CFG            (* (reg8 *) DSBout__SIO_CFG)
    #define DSBout_SIO_DIFF           (* (reg8 *) DSBout__SIO_DIFF)
#endif /* (DSBout__SIO_CFG) */

/* Interrupt Registers */
#if defined(DSBout__INTSTAT)
    #define DSBout_INTSTAT            (* (reg8 *) DSBout__INTSTAT)
    #define DSBout_SNAP               (* (reg8 *) DSBout__SNAP)
    
	#define DSBout_0_INTTYPE_REG 		(* (reg8 *) DSBout__0__INTTYPE)
#endif /* (DSBout__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_DSBout_H */


/* [] END OF FILE */
