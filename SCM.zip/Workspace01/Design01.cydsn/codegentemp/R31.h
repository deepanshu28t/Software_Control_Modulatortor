/*******************************************************************************
* File Name: R31.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_R31_H) /* Pins R31_H */
#define CY_PINS_R31_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "R31_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 R31__PORT == 15 && ((R31__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    R31_Write(uint8 value);
void    R31_SetDriveMode(uint8 mode);
uint8   R31_ReadDataReg(void);
uint8   R31_Read(void);
void    R31_SetInterruptMode(uint16 position, uint16 mode);
uint8   R31_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the R31_SetDriveMode() function.
     *  @{
     */
        #define R31_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define R31_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define R31_DM_RES_UP          PIN_DM_RES_UP
        #define R31_DM_RES_DWN         PIN_DM_RES_DWN
        #define R31_DM_OD_LO           PIN_DM_OD_LO
        #define R31_DM_OD_HI           PIN_DM_OD_HI
        #define R31_DM_STRONG          PIN_DM_STRONG
        #define R31_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define R31_MASK               R31__MASK
#define R31_SHIFT              R31__SHIFT
#define R31_WIDTH              1u

/* Interrupt constants */
#if defined(R31__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in R31_SetInterruptMode() function.
     *  @{
     */
        #define R31_INTR_NONE      (uint16)(0x0000u)
        #define R31_INTR_RISING    (uint16)(0x0001u)
        #define R31_INTR_FALLING   (uint16)(0x0002u)
        #define R31_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define R31_INTR_MASK      (0x01u) 
#endif /* (R31__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define R31_PS                     (* (reg8 *) R31__PS)
/* Data Register */
#define R31_DR                     (* (reg8 *) R31__DR)
/* Port Number */
#define R31_PRT_NUM                (* (reg8 *) R31__PRT) 
/* Connect to Analog Globals */                                                  
#define R31_AG                     (* (reg8 *) R31__AG)                       
/* Analog MUX bux enable */
#define R31_AMUX                   (* (reg8 *) R31__AMUX) 
/* Bidirectional Enable */                                                        
#define R31_BIE                    (* (reg8 *) R31__BIE)
/* Bit-mask for Aliased Register Access */
#define R31_BIT_MASK               (* (reg8 *) R31__BIT_MASK)
/* Bypass Enable */
#define R31_BYP                    (* (reg8 *) R31__BYP)
/* Port wide control signals */                                                   
#define R31_CTL                    (* (reg8 *) R31__CTL)
/* Drive Modes */
#define R31_DM0                    (* (reg8 *) R31__DM0) 
#define R31_DM1                    (* (reg8 *) R31__DM1)
#define R31_DM2                    (* (reg8 *) R31__DM2) 
/* Input Buffer Disable Override */
#define R31_INP_DIS                (* (reg8 *) R31__INP_DIS)
/* LCD Common or Segment Drive */
#define R31_LCD_COM_SEG            (* (reg8 *) R31__LCD_COM_SEG)
/* Enable Segment LCD */
#define R31_LCD_EN                 (* (reg8 *) R31__LCD_EN)
/* Slew Rate Control */
#define R31_SLW                    (* (reg8 *) R31__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define R31_PRTDSI__CAPS_SEL       (* (reg8 *) R31__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define R31_PRTDSI__DBL_SYNC_IN    (* (reg8 *) R31__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define R31_PRTDSI__OE_SEL0        (* (reg8 *) R31__PRTDSI__OE_SEL0) 
#define R31_PRTDSI__OE_SEL1        (* (reg8 *) R31__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define R31_PRTDSI__OUT_SEL0       (* (reg8 *) R31__PRTDSI__OUT_SEL0) 
#define R31_PRTDSI__OUT_SEL1       (* (reg8 *) R31__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define R31_PRTDSI__SYNC_OUT       (* (reg8 *) R31__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(R31__SIO_CFG)
    #define R31_SIO_HYST_EN        (* (reg8 *) R31__SIO_HYST_EN)
    #define R31_SIO_REG_HIFREQ     (* (reg8 *) R31__SIO_REG_HIFREQ)
    #define R31_SIO_CFG            (* (reg8 *) R31__SIO_CFG)
    #define R31_SIO_DIFF           (* (reg8 *) R31__SIO_DIFF)
#endif /* (R31__SIO_CFG) */

/* Interrupt Registers */
#if defined(R31__INTSTAT)
    #define R31_INTSTAT            (* (reg8 *) R31__INTSTAT)
    #define R31_SNAP               (* (reg8 *) R31__SNAP)
    
	#define R31_0_INTTYPE_REG 		(* (reg8 *) R31__0__INTTYPE)
#endif /* (R31__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_R31_H */


/* [] END OF FILE */
