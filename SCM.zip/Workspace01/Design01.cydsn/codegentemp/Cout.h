/*******************************************************************************
* File Name: Cout.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Cout_H) /* Pins Cout_H */
#define CY_PINS_Cout_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Cout_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Cout__PORT == 15 && ((Cout__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Cout_Write(uint8 value);
void    Cout_SetDriveMode(uint8 mode);
uint8   Cout_ReadDataReg(void);
uint8   Cout_Read(void);
void    Cout_SetInterruptMode(uint16 position, uint16 mode);
uint8   Cout_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Cout_SetDriveMode() function.
     *  @{
     */
        #define Cout_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Cout_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Cout_DM_RES_UP          PIN_DM_RES_UP
        #define Cout_DM_RES_DWN         PIN_DM_RES_DWN
        #define Cout_DM_OD_LO           PIN_DM_OD_LO
        #define Cout_DM_OD_HI           PIN_DM_OD_HI
        #define Cout_DM_STRONG          PIN_DM_STRONG
        #define Cout_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Cout_MASK               Cout__MASK
#define Cout_SHIFT              Cout__SHIFT
#define Cout_WIDTH              1u

/* Interrupt constants */
#if defined(Cout__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Cout_SetInterruptMode() function.
     *  @{
     */
        #define Cout_INTR_NONE      (uint16)(0x0000u)
        #define Cout_INTR_RISING    (uint16)(0x0001u)
        #define Cout_INTR_FALLING   (uint16)(0x0002u)
        #define Cout_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Cout_INTR_MASK      (0x01u) 
#endif /* (Cout__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Cout_PS                     (* (reg8 *) Cout__PS)
/* Data Register */
#define Cout_DR                     (* (reg8 *) Cout__DR)
/* Port Number */
#define Cout_PRT_NUM                (* (reg8 *) Cout__PRT) 
/* Connect to Analog Globals */                                                  
#define Cout_AG                     (* (reg8 *) Cout__AG)                       
/* Analog MUX bux enable */
#define Cout_AMUX                   (* (reg8 *) Cout__AMUX) 
/* Bidirectional Enable */                                                        
#define Cout_BIE                    (* (reg8 *) Cout__BIE)
/* Bit-mask for Aliased Register Access */
#define Cout_BIT_MASK               (* (reg8 *) Cout__BIT_MASK)
/* Bypass Enable */
#define Cout_BYP                    (* (reg8 *) Cout__BYP)
/* Port wide control signals */                                                   
#define Cout_CTL                    (* (reg8 *) Cout__CTL)
/* Drive Modes */
#define Cout_DM0                    (* (reg8 *) Cout__DM0) 
#define Cout_DM1                    (* (reg8 *) Cout__DM1)
#define Cout_DM2                    (* (reg8 *) Cout__DM2) 
/* Input Buffer Disable Override */
#define Cout_INP_DIS                (* (reg8 *) Cout__INP_DIS)
/* LCD Common or Segment Drive */
#define Cout_LCD_COM_SEG            (* (reg8 *) Cout__LCD_COM_SEG)
/* Enable Segment LCD */
#define Cout_LCD_EN                 (* (reg8 *) Cout__LCD_EN)
/* Slew Rate Control */
#define Cout_SLW                    (* (reg8 *) Cout__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Cout_PRTDSI__CAPS_SEL       (* (reg8 *) Cout__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Cout_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Cout__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Cout_PRTDSI__OE_SEL0        (* (reg8 *) Cout__PRTDSI__OE_SEL0) 
#define Cout_PRTDSI__OE_SEL1        (* (reg8 *) Cout__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Cout_PRTDSI__OUT_SEL0       (* (reg8 *) Cout__PRTDSI__OUT_SEL0) 
#define Cout_PRTDSI__OUT_SEL1       (* (reg8 *) Cout__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Cout_PRTDSI__SYNC_OUT       (* (reg8 *) Cout__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Cout__SIO_CFG)
    #define Cout_SIO_HYST_EN        (* (reg8 *) Cout__SIO_HYST_EN)
    #define Cout_SIO_REG_HIFREQ     (* (reg8 *) Cout__SIO_REG_HIFREQ)
    #define Cout_SIO_CFG            (* (reg8 *) Cout__SIO_CFG)
    #define Cout_SIO_DIFF           (* (reg8 *) Cout__SIO_DIFF)
#endif /* (Cout__SIO_CFG) */

/* Interrupt Registers */
#if defined(Cout__INTSTAT)
    #define Cout_INTSTAT            (* (reg8 *) Cout__INTSTAT)
    #define Cout_SNAP               (* (reg8 *) Cout__SNAP)
    
	#define Cout_0_INTTYPE_REG 		(* (reg8 *) Cout__0__INTTYPE)
#endif /* (Cout__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Cout_H */


/* [] END OF FILE */
