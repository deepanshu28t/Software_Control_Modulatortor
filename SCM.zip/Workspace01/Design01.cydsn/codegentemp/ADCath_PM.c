/*******************************************************************************
* File Name: ADCath_PM.c
* Version 3.10
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "ADCath.h"


/***************************************
* Local data allocation
***************************************/

static ADCath_BACKUP_STRUCT  ADCath_backup =
{
    ADCath_DISABLED
};


/*******************************************************************************
* Function Name: ADCath_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void ADCath_SaveConfig(void)
{
    /* All configuration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: ADCath_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void ADCath_RestoreConfig(void)
{
    /* All congiguration registers are marked as [reset_all_retention] */
}


/*******************************************************************************
* Function Name: ADCath_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred routine to prepare the component for sleep.
*  The ADCath_Sleep() routine saves the current component state,
*  then it calls the ADC_Stop() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  ADCath_backup - The structure field 'enableState' is modified
*  depending on the enable state of the block before entering to sleep mode.
*
*******************************************************************************/
void ADCath_Sleep(void)
{
    if((ADCath_PWRMGR_SAR_REG  & ADCath_ACT_PWR_SAR_EN) != 0u)
    {
        if((ADCath_SAR_CSR0_REG & ADCath_SAR_SOF_START_CONV) != 0u)
        {
            ADCath_backup.enableState = ADCath_ENABLED | ADCath_STARTED;
        }
        else
        {
            ADCath_backup.enableState = ADCath_ENABLED;
        }
        ADCath_Stop();
    }
    else
    {
        ADCath_backup.enableState = ADCath_DISABLED;
    }
}


/*******************************************************************************
* Function Name: ADCath_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred routine to restore the component to the state when
*  ADCath_Sleep() was called. If the component was enabled before the
*  ADCath_Sleep() function was called, the
*  ADCath_Wakeup() function also re-enables the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  ADCath_backup - The structure field 'enableState' is used to
*  restore the enable state of block after wakeup from sleep mode.
*
*******************************************************************************/
void ADCath_Wakeup(void)
{
    if(ADCath_backup.enableState != ADCath_DISABLED)
    {
        ADCath_Enable();
        #if(ADCath_DEFAULT_CONV_MODE != ADCath__HARDWARE_TRIGGER)
            if((ADCath_backup.enableState & ADCath_STARTED) != 0u)
            {
                ADCath_StartConvert();
            }
        #endif /* End ADCath_DEFAULT_CONV_MODE != ADCath__HARDWARE_TRIGGER */
    }
}


/* [] END OF FILE */
