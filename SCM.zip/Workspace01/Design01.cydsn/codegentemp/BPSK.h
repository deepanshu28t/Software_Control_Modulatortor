/*******************************************************************************
* File Name: BPSK.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BPSK_H) /* Pins BPSK_H */
#define CY_PINS_BPSK_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BPSK_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BPSK__PORT == 15 && ((BPSK__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    BPSK_Write(uint8 value);
void    BPSK_SetDriveMode(uint8 mode);
uint8   BPSK_ReadDataReg(void);
uint8   BPSK_Read(void);
void    BPSK_SetInterruptMode(uint16 position, uint16 mode);
uint8   BPSK_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the BPSK_SetDriveMode() function.
     *  @{
     */
        #define BPSK_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define BPSK_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define BPSK_DM_RES_UP          PIN_DM_RES_UP
        #define BPSK_DM_RES_DWN         PIN_DM_RES_DWN
        #define BPSK_DM_OD_LO           PIN_DM_OD_LO
        #define BPSK_DM_OD_HI           PIN_DM_OD_HI
        #define BPSK_DM_STRONG          PIN_DM_STRONG
        #define BPSK_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define BPSK_MASK               BPSK__MASK
#define BPSK_SHIFT              BPSK__SHIFT
#define BPSK_WIDTH              1u

/* Interrupt constants */
#if defined(BPSK__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in BPSK_SetInterruptMode() function.
     *  @{
     */
        #define BPSK_INTR_NONE      (uint16)(0x0000u)
        #define BPSK_INTR_RISING    (uint16)(0x0001u)
        #define BPSK_INTR_FALLING   (uint16)(0x0002u)
        #define BPSK_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define BPSK_INTR_MASK      (0x01u) 
#endif /* (BPSK__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BPSK_PS                     (* (reg8 *) BPSK__PS)
/* Data Register */
#define BPSK_DR                     (* (reg8 *) BPSK__DR)
/* Port Number */
#define BPSK_PRT_NUM                (* (reg8 *) BPSK__PRT) 
/* Connect to Analog Globals */                                                  
#define BPSK_AG                     (* (reg8 *) BPSK__AG)                       
/* Analog MUX bux enable */
#define BPSK_AMUX                   (* (reg8 *) BPSK__AMUX) 
/* Bidirectional Enable */                                                        
#define BPSK_BIE                    (* (reg8 *) BPSK__BIE)
/* Bit-mask for Aliased Register Access */
#define BPSK_BIT_MASK               (* (reg8 *) BPSK__BIT_MASK)
/* Bypass Enable */
#define BPSK_BYP                    (* (reg8 *) BPSK__BYP)
/* Port wide control signals */                                                   
#define BPSK_CTL                    (* (reg8 *) BPSK__CTL)
/* Drive Modes */
#define BPSK_DM0                    (* (reg8 *) BPSK__DM0) 
#define BPSK_DM1                    (* (reg8 *) BPSK__DM1)
#define BPSK_DM2                    (* (reg8 *) BPSK__DM2) 
/* Input Buffer Disable Override */
#define BPSK_INP_DIS                (* (reg8 *) BPSK__INP_DIS)
/* LCD Common or Segment Drive */
#define BPSK_LCD_COM_SEG            (* (reg8 *) BPSK__LCD_COM_SEG)
/* Enable Segment LCD */
#define BPSK_LCD_EN                 (* (reg8 *) BPSK__LCD_EN)
/* Slew Rate Control */
#define BPSK_SLW                    (* (reg8 *) BPSK__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BPSK_PRTDSI__CAPS_SEL       (* (reg8 *) BPSK__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BPSK_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BPSK__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BPSK_PRTDSI__OE_SEL0        (* (reg8 *) BPSK__PRTDSI__OE_SEL0) 
#define BPSK_PRTDSI__OE_SEL1        (* (reg8 *) BPSK__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BPSK_PRTDSI__OUT_SEL0       (* (reg8 *) BPSK__PRTDSI__OUT_SEL0) 
#define BPSK_PRTDSI__OUT_SEL1       (* (reg8 *) BPSK__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BPSK_PRTDSI__SYNC_OUT       (* (reg8 *) BPSK__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(BPSK__SIO_CFG)
    #define BPSK_SIO_HYST_EN        (* (reg8 *) BPSK__SIO_HYST_EN)
    #define BPSK_SIO_REG_HIFREQ     (* (reg8 *) BPSK__SIO_REG_HIFREQ)
    #define BPSK_SIO_CFG            (* (reg8 *) BPSK__SIO_CFG)
    #define BPSK_SIO_DIFF           (* (reg8 *) BPSK__SIO_DIFF)
#endif /* (BPSK__SIO_CFG) */

/* Interrupt Registers */
#if defined(BPSK__INTSTAT)
    #define BPSK_INTSTAT            (* (reg8 *) BPSK__INTSTAT)
    #define BPSK_SNAP               (* (reg8 *) BPSK__SNAP)
    
	#define BPSK_0_INTTYPE_REG 		(* (reg8 *) BPSK__0__INTTYPE)
#endif /* (BPSK__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BPSK_H */


/* [] END OF FILE */
